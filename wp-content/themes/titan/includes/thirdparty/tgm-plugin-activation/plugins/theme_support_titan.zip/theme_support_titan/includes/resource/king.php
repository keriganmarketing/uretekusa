<?php
/**
 * Kingcomposer array
 *
 * @package Student WP
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

$orderby = array(
				"type"			=>	"select",
				"label"			=>	esc_html__("Order By", BUNCH_NAME),
				"name"			=>	"sort",
				'options'		=>	array('date'=>esc_html__('Date', BUNCH_NAME),'title'=>esc_html__('Title', BUNCH_NAME) ,'name'=>esc_html__('Name', BUNCH_NAME) ,'author'=>esc_html__('Author', BUNCH_NAME),'comment_count' =>esc_html__('Comment Count', BUNCH_NAME),'random' =>esc_html__('Random', BUNCH_NAME) ),
				"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
			);
$rvslider = array(
				'type' => 'dropdown',
				'label' => esc_html__('Choose Slider', BUNCH_NAME ),
				'name' => 'slider_slug',
				'options' => bunch_get_rev_slider( 0 ),
				'description' => esc_html__('Choose Slider', BUNCH_NAME )
			);
$order = array(
				"type"			=>	"select",
				"label"			=>	esc_html__("Order", BUNCH_NAME),
				"name"			=>	"order",
				'options'		=>	(array('ASC'=>esc_html__('Ascending', BUNCH_NAME),'DESC'=>esc_html__('Descending', BUNCH_NAME) ) ),			
				"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
			);
$number = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Number', BUNCH_NAME ),
				"name"			=>	"num",
				"description"	=>	esc_html__('Enter Number of posts to Show.', BUNCH_NAME )
			);
$text_limit = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Text Limit', BUNCH_NAME ),
				"name"			=>	"text_limit",
				"description"	=>	esc_html__('Enter text limit of posts to Show.', BUNCH_NAME )
			);
$title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"title",
				"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
			);
$subtitle = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Sub-Title', BUNCH_NAME ),
				"name"			=>	"subtitle",
				"description"	=>	esc_html__('Enter section subtitle.', BUNCH_NAME )
			);
$text = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Text', BUNCH_NAME ),
				"name"			=>	"text",
				"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
			);
$editor  = array(
				"type"			=>	"editor",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"editor",
				"description"	=>	esc_html__('Enter title to show.', BUNCH_NAME )
			);
$email = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Email', BUNCH_NAME ),
				"name"			=>	"email",
				"description"	=>	esc_html__('Enter email.', BUNCH_NAME )
			);
$phone = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Phone', BUNCH_NAME ),
				"name"			=>	"phone",
				"description"	=>	esc_html__('Enter phone.', BUNCH_NAME )
			);
$address = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Address', BUNCH_NAME ),
				"name"			=>	"address",
				"description"	=>	esc_html__('Enter address.', BUNCH_NAME )
			);
$website = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Website', BUNCH_NAME ),
				"name"			=>	"website",
				"description"	=>	esc_html__('Enter website.', BUNCH_NAME )
			);
$working_hours = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Working Hours', BUNCH_NAME ),
				"name"			=>	"working_hours",
				"description"	=>	esc_html__('Enter Working Hours.', BUNCH_NAME )
			);
$contact_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Contact Us Title', BUNCH_NAME ),
				"name"			=>	"contact_title",
				"description"	=>	esc_html__('Enter contact us title.', BUNCH_NAME )
			);
$contact_text = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Contact Us Description', BUNCH_NAME ),
				"name"			=>	"contact_text",
				"description"	=>	esc_html__('Enter contact us description.', BUNCH_NAME )
			);
$contact_shortcode = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Contact Us Shortcode', BUNCH_NAME ),
				"name"			=>	"contact_shortcode",
				"description"	=>	esc_html__('Enter contact us shortcode to show.', BUNCH_NAME )
			);
$latitude = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Latitude', BUNCH_NAME ),
				"name"			=>	"latitude",
				"description"	=>	esc_html__('Enter latitude.', BUNCH_NAME )
			);
$longitude = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Longitude', BUNCH_NAME ),
				"name"			=>	"longitude",
				"description"	=>	esc_html__('Enter longitude.', BUNCH_NAME )
			);
$zoom = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Map Zoom', BUNCH_NAME ),
				"name"			=>	"zoom",
				"description"	=>	esc_html__('Enter map zoom.', BUNCH_NAME )
			);
$btn_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Button Title', BUNCH_NAME ),
				"name"			=>	"btn_title",
				"description"	=>	esc_html__('Enter section Button title.', BUNCH_NAME )
			);
$btn_link = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Button Link', BUNCH_NAME ),
				"name"			=>	"btn_link",
				"description"	=>	esc_html__('Enter section Button Link.', BUNCH_NAME ),
				'value'	=> '#',
			);
$img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Image', BUNCH_NAME ),
				"name"			=>	"img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose Image.', BUNCH_NAME )
			);
$bg_img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Background Image', BUNCH_NAME ),
				"name"			=>	"bg_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose Background image.', BUNCH_NAME )
			);
$multi_img = array(
				"type"			=>	"attach_images",
				"label"			=>	esc_html__('Multi Images', BUNCH_NAME ),
				"name"			=>	"multi_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Uplod multi images.', BUNCH_NAME )
			);
$signature = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Signature', BUNCH_NAME ),
				"name"			=>	"signature",
				"description"	=>	esc_html__('Choose Signature.', BUNCH_NAME )
			);
$video = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Video URL', BUNCH_NAME ),
				"name"			=>	"video",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Enter video url.', BUNCH_NAME )
			);
$video_img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Video Image', BUNCH_NAME ),
				"name"			=>	"video_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose video image.', BUNCH_NAME )
			);
$video_text = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Video Description', BUNCH_NAME ),
				"name"			=>	"video_text",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Enter video Description.', BUNCH_NAME )
			);
$icon = array(
				'type' => 'icon_picker',
				'label' => esc_html__('Icon', BUNCH_NAME ),
				'name' => 'icon',
				'description' => esc_html__('Enter your icon', BUNCH_NAME )
			);
$url = array(
				'type' => 'text',
				'label' => esc_html__('URL', BUNCH_NAME ),
				'name' => 'url',
				'description' => esc_html__('Enter url', BUNCH_NAME ),
				'value'	=> '#',
			);
$ff_start = array(
				'type' => 'text',
				'label' => esc_html__('Counter Start', BUNCH_NAME ),
				'name' => 'ff_start',
				'description' => esc_html__('Enter Counter Start', BUNCH_NAME ),
				'value'	=> '1',
			);
$ff_end = array(
				'type' => 'text',
				'label' => esc_html__('Counter End', BUNCH_NAME ),
				'name' => 'ff_end',
				'description' => esc_html__('Enter Counter End', BUNCH_NAME )
			);
$ff_sign = array(
				'type' => 'text',
				'label' => esc_html__('Counter Sign', BUNCH_NAME ),
				'name' => 'ff_sign',
				'description' => esc_html__('Enter Counter Sign', BUNCH_NAME )
			);
$date = array(
				'type' => 'text',
				'label' => esc_html__('Date', BUNCH_NAME ),
				'name' => 'date',
				'description' => esc_html__('Enter Date', BUNCH_NAME )
			);
$cat = array(
				"type" => "dropdown",
				"label" => __('Category', BUNCH_NAME),
				"name" => "cat",
				"options" =>  bunch_get_categories(array('taxonomy' => 'category'), true),
				"description" => __('Choose Category.', BUNCH_NAME)
			);
$services_cat = array(
				"type" => "dropdown",
				"label" => __( 'Category', BUNCH_NAME),
				"name" => "cat",
				"options" =>  bunch_get_categories(array( 'taxonomy' => 'services_category'), true),
				"description" => __( 'Choose Category.', BUNCH_NAME)
			);
$projects_cat = array(
				"type" => "dropdown",
				"label" => __( 'Category', BUNCH_NAME),
				"name" => "cat",
				"options" =>  bunch_get_categories(array( 'taxonomy' => 'projects_category'), true),
				"description" => __( 'Choose Category.', BUNCH_NAME)
			);
$team_cat = array(
				"type" => "dropdown",
				"label" => __( 'Category', BUNCH_NAME),
				"name" => "cat",
				"options" =>  bunch_get_categories(array( 'taxonomy' => 'team_category'), true),
				"description" => __( 'Choose Category.', BUNCH_NAME)
			);
$testimonials_cat = array(
					"type" => "dropdown",
					"label" => __( 'Category', BUNCH_NAME),
					"name" => "cat",
					"options" =>  bunch_get_categories(array( 'taxonomy' => 'testimonials_category'), true),
					"description" => __( 'Choose Category.', BUNCH_NAME)
				);
$faqs_cat = array(
					"type" => "dropdown",
					"label" => __( 'Category', BUNCH_NAME),
					"name" => "cat",
					"options" =>  bunch_get_categories(array( 'taxonomy' => 'faqs_category'), true),
					"description" => __( 'Choose Category.', BUNCH_NAME)
				);
$exclude_cats = array(
				   "type" => "textfield",
				   "label" => __('Excluded Categories ID', BUNCH_NAME ),
				   "name" => "exclude_cats",
				   "description" => __('Enter Excluded Categories ID seperated by commas(13,14).', BUNCH_NAME )
				);

$options = array();


// Revslider
$options['bunch_revslider']	=	array(
					'name' => esc_html__('Revslider', BUNCH_NAME),
					'base' => 'bunch_revslider',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Revolution slider.', BUNCH_NAME),
					'params' => array(
						$rvslider
					),
			);
//About Us Home
$options['bunch_about_us']	= array(
					'name' => esc_html__('About Us', BUNCH_NAME),
					'base' => 'bunch_about_us',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show About Us.', BUNCH_NAME),
					'params' => array(
						$img,
						$editor,
						$text,
						array(
							'type' => 'group',
							'label' => esc_html__( 'About Us', BUNCH_NAME ),
							'name' => 'about_us',
							'description' => esc_html__( 'Enter About Us Details.', BUNCH_NAME ),
							'params' => array(
								$title,
								$icon,
							),
						),
						$btn_title,
						$btn_link,
					),
			);
//Our Features
$options['bunch_our_features'] = array(
					'name' => esc_html__('Our Features', BUNCH_NAME),
					'base' => 'bunch_our_features',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Services Home.', BUNCH_NAME),
					'params' => array(
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							$bg_img,
							$title,
							$text,
							$btn_title,
							$btn_link,
						),
						//Tabs Start
						esc_html__( 'Our Features Right', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title_r",
								"description"	=>	esc_html__('Enter year.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Content', BUNCH_NAME ),
								"name"			=>	"text_r",
								"description"	=>	esc_html__('Enter section content.', BUNCH_NAME )
							),
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Button Title', BUNCH_NAME ),
								"name"			=>	"btn_title_r",
								"description"	=>	esc_html__('Enter section Button title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Button Link', BUNCH_NAME ),
								"name"			=>	"btn_link_r",
								"description"	=>	esc_html__('Enter section Button Link.', BUNCH_NAME ),
								'value'	=> '#',
							),
						),
					),
			);			
//Our Services
$options['bunch_our_services'] = array(
					'name' => esc_html__('Our Services', BUNCH_NAME),
					'base' => 'bunch_our_services',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Services.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$img,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Call Out
$options['bunch_call_out'] = array(
					'name' => esc_html__('Call Out', BUNCH_NAME),
					'base' => 'bunch_call_out',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Call Out.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$editor,
						$text,
						$btn_title,
						$btn_link,
					),
			);
//Our Latest Projects
$options['bunch_our_latest_projects'] = array(
					'name' => esc_html__('Our Latest Projects', BUNCH_NAME),
					'base' => 'bunch_our_latest_projects',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Latest Projects.', BUNCH_NAME),
					'params' => array(
						$title,
						$number,
						$exclude_cats,
						$orderby,
						$order,
					),
			);
//Our Great Team
$options['bunch_our_team_home'] = array(
					'name' => esc_html__('Our Great Team', BUNCH_NAME),
					'base' => 'bunch_our_team_home',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Our Team on home.', BUNCH_NAME),
					'params' => array(
						$title,
						$number,
						$team_cat,
						$orderby,
						$order,
					),
			);
//Latest News
$options['bunch_latest_news'] = array(
					'name' => esc_html__('Latest News', BUNCH_NAME),
					'base' => 'bunch_latest_news',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Latest News.', BUNCH_NAME),
					'params' => array(
						$title,
						$text_limit,
						$number,
						$cat,
						$orderby,
						$order,
					),
			);
//Clients Logo
$options['bunch_clients']	=	array(
					'name' => esc_html__('Clients', BUNCH_NAME),
					'base' => 'bunch_clients',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-users' ,
					'description' => esc_html__('Show Clients Logo images.', BUNCH_NAME),
					'params' => array(
						array(
							'type' => 'group',
							'label' => esc_html__( 'Clients Logo', BUNCH_NAME ),
							'name' => 'our_clients',
							'description' => esc_html__( 'Enter Clients Logo', BUNCH_NAME ),
							'params' => array(
								$title,
								$img,
								$url,
							),
						),
					),
			);
// Google Map
$options['bunch_google_map']	=	array(
					'name' => esc_html__('Google Map', BUNCH_NAME),
					'base' => 'bunch_google_map',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-envelope' ,
					'description' => esc_html__('Show Google Map and Contact Details.', BUNCH_NAME),
					'params' => array(
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Map Title', BUNCH_NAME ),
								"name"			=>	"map_title",
								"description"	=>	esc_html__('Enter section subtitle.', BUNCH_NAME )
							),
							$latitude,
							$longitude,
							$zoom,
						),
						//Tabs Start
						esc_html__( 'Contact Details', BUNCH_NAME ) => array(
							$title,
							$address,
							$email,
							$phone,
							array(
								'type' => 'group',
								'label' => esc_html__( 'Social Media Icons', BUNCH_NAME ),
								'name' => 'social_icons',
								'description' => esc_html__( 'Enter Social Media icons', BUNCH_NAME ),
								'params' => array(
									$title,
									$icon,
									$url,
								),
							),
						),
					),
			);
//Services 2
$options['bunch_our_services2'] = array(
					'name' => esc_html__('We Are Builder', BUNCH_NAME),
					'base' => 'bunch_our_services2',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show We Are Builder.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Call Out 2
$options['bunch_call_out2'] = array(
					'name' => esc_html__('Call Out 2', BUNCH_NAME),
					'base' => 'bunch_call_out2',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Call Out 2.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$subtitle,
						$btn_title,
						$btn_link,
					),
			);
//Services 3
$options['bunch_our_services3'] = array(
					'name' => esc_html__('Our Service 3', BUNCH_NAME),
					'base' => 'bunch_our_services3',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show We Are Builder.', BUNCH_NAME),
					'params' => array(
						$img,
						$editor,
						$text,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Projects
$options['bunch_projects'] = array(
					'name' => esc_html__('Projects', BUNCH_NAME),
					'base' => 'bunch_projects',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Projects.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$number,
						$exclude_cats,
						$orderby,
						$order,
						$btn_title,
						$btn_link,
					),
			);
//Our Great Team
$options['bunch_our_team_home2'] = array(
					'name' => esc_html__('Our Team 2', BUNCH_NAME),
					'base' => 'bunch_our_team_home2',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Our Team on home 2.', BUNCH_NAME),
					'params' => array(
						$title,
						$text_limit,
						$number,
						$team_cat,
						$orderby,
						$order,
					),
			);
//Blog
$options['bunch_blog'] = array(
					'name' => esc_html__('Blog', BUNCH_NAME),
					'base' => 'bunch_blog',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Latest Blog.', BUNCH_NAME),
					'params' => array(
						$title,
						$text_limit,
						$number,
						$cat,
						$orderby,
						$order,
					),
			);
//Welcome to Construct Press 1
$options['bunch_welcome_construct_press'] = array(
					'name' => esc_html__('Construct Press 1', BUNCH_NAME),
					'base' => 'bunch_welcome_construct_press',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Welcome to Construct Press.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Price Plan
$options['bunch_price_plan'] = array(
					'name' => esc_html__('Price Plan', BUNCH_NAME),
					'base' => 'bunch_price_plan',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-usd' ,
					'description' => esc_html__('Show Price Plan.', BUNCH_NAME),
					'params' => array(
						$title,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Price Plan', BUNCH_NAME ),
							'name' => 'pricing_plan',
							'description' => esc_html__( 'Enter Price Plan detail.', BUNCH_NAME ),
							'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Price Plan Title', BUNCH_NAME ),
									'name' => 'price_title',
									'description' => esc_html__( 'Enter Price Plan Title.', BUNCH_NAME ),
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Currency Sign', BUNCH_NAME ),
									'name' => 'sign',
									'description' => esc_html__( 'Enter Currency Sign.', BUNCH_NAME ),
									'value' => '$'
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Amount', BUNCH_NAME ),
									'name' => 'amount',
									'description' => esc_html__( 'Enter Name.', BUNCH_NAME ),
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Month', BUNCH_NAME ),
									'name' => 'month',
									'description' => esc_html__( 'Enter Description.', BUNCH_NAME ),
									'value' => 'PH'
								),
								$text,
								$btn_title,
								$btn_link,
							),
						),
					),
			);
//Our Dedicated Team
$options['bunch_our_dedicated_team'] = array(
					'name' => esc_html__('Our Dedicated Team', BUNCH_NAME),
					'base' => 'bunch_our_dedicated_team',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Our Dedicated Team.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text_limit,
						$number,
						$team_cat,
						$orderby,
						$order,
					),
			);
//Welcome to Construct Press 2
$options['bunch_welcome_construct_press2'] = array(
					'name' => esc_html__('Construct Press 2', BUNCH_NAME),
					'base' => 'bunch_welcome_construct_press2',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Welcome to Construct Press 2.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$img,
						$title,
						$text,
					),
			);
//Why Choose Our Titan Builder
$options['bunch_our_titan_Builder'] = array(
					'name' => esc_html__('Our Titan Builder', BUNCH_NAME),
					'base' => 'bunch_our_titan_Builder',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Why Choose Our Titan Builder.', BUNCH_NAME),
					'params' => array(
						$title,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Our Construction
$options['bunch_our_construction'] = array(
					'name' => esc_html__('Our Construction', BUNCH_NAME),
					'base' => 'bunch_our_titan_Builder',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Why Choose Our Titan Builder.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Our Team
$options['bunch_our_team'] = array(
					'name' => esc_html__('Our Team', BUNCH_NAME),
					'base' => 'bunch_our_team',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Our Team.', BUNCH_NAME),
					'params' => array(
						$number,
						$team_cat,
						$orderby,
						$order,
					),
			);
//FAQs & Contact Form
$options['bunch_faqs'] = array(
					'name' => esc_html__('FAQs - Contact Form', BUNCH_NAME),
					'base' => 'bunch_faqs',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show FAQs.', BUNCH_NAME),
					'params' => array(
						esc_html__( 'FAQs', BUNCH_NAME ) => array(
							$number,
							$faqs_cat,
							$orderby,
							$order,
						),
						esc_html__( 'Contact Form', BUNCH_NAME ) => array(
							$contact_title,
							$contact_shortcode,
						),
					),
			);
//Services Single
$options['bunch_services_single'] = array(
					'name' => esc_html__('Services Single', BUNCH_NAME),
					'base' => 'bunch_services_single',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Services Single.', BUNCH_NAME),
					'params' => array(
						$img,
						$text,
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Bottom Text', BUNCH_NAME ),
							"name"			=>	"text2",
							"description"	=>	esc_html__('Enter Bottom Text to show.', BUNCH_NAME )
						),
						array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Planning Title', BUNCH_NAME ),
							"name"			=>	"planing_title",
							"description"	=>	esc_html__('Enter title of posts to Show.', BUNCH_NAME )
						),
						array(
							"type"			=>	"attach_image_url",
							"label"			=>	esc_html__('Planning Image', BUNCH_NAME ),
							"name"			=>	"planing_img",
							'admin_label' 	=> 	false,
							"description"	=>	esc_html__('Choose Image.', BUNCH_NAME )
						),
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Planning Text', BUNCH_NAME ),
							"name"			=>	"planing_text",
							"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
						),
						array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Our Work Process Title', BUNCH_NAME ),
							"name"			=>	"work_title",
							"description"	=>	esc_html__('Enter title to Show.', BUNCH_NAME )
						),
						array(
							"type"			=>	"attach_image_url",
							"label"			=>	esc_html__('Work Image', BUNCH_NAME ),
							"name"			=>	"work_img",
							'admin_label' 	=> 	false,
							"description"	=>	esc_html__('Choose Image.', BUNCH_NAME )
						),
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Planning Text', BUNCH_NAME ),
							"name"			=>	"work_text",
							"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
						),
					),
			);
//Projects 4 Columns
$options['bunch_projects_4_col'] = array(
					'name' => esc_html__('Projects 4 Columns', BUNCH_NAME),
					'base' => 'bunch_projects_4_col',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Projects 4 Columns.', BUNCH_NAME),
					'params' => array(
						$number,
						$exclude_cats,
						$orderby,
						$order,
					),
			);
//Projects 3 Columns
$options['bunch_projects_3_col'] = array(
					'name' => esc_html__('Projects 3 Columns', BUNCH_NAME),
					'base' => 'bunch_projects_3_col',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Projects 3 Columns.', BUNCH_NAME),
					'params' => array(
						$number,
						$exclude_cats,
						$orderby,
						$order,
					),
			);
//Projects 2 Columns
$options['bunch_projects_2_col'] = array(
					'name' => esc_html__('Projects 2 Columns', BUNCH_NAME),
					'base' => 'bunch_projects_2_col',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Projects 2 Columns.', BUNCH_NAME),
					'params' => array(
						$number,
						$exclude_cats,
						$orderby,
						$order,
					),
			);
//Contact Us
$options['bunch_contact_us'] = array(
					'name' => esc_html__('Contact Us', BUNCH_NAME),
					'base' => 'bunch_contact_us',
					'class' => '',
					'category' => esc_html__('Titan Builder', BUNCH_NAME),
					'icon' => 'fa-envelope' ,
					'description' => esc_html__('Show contact detail.', BUNCH_NAME),
					'params' => array(
						$editor,
						$text,
						$img,
						$contact_shortcode,
					),
			);

return $options;